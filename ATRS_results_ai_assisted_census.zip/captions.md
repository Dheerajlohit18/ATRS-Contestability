# Figure and table captions

## RQ1_F1 Contestation wording in the record corpus
AUTOMATED LEXICAL CENSUS | 153 published records. Numerators and denominators shown. Positives are lexical matches, not validated procedures; non-detection is not evidence of absence.

## RQ1_F2 Nested contestation cue combinations
AUTOMATED LEXICAL CENSUS | 153 published records. The ordering is an analytical intersection, not an observed appeal journey or causal funnel. It does not establish that a route works in practice.

## RQ1_T1 Corpus and lexical census denominator
AUTOMATED LEXICAL CENSUS | 153 published records. All published records in the frozen snapshot are included by design, including internal and general information tools.

## RQ1_T2 Ten most frequent lexical cue profiles
AUTOMATED LEXICAL CENSUS | 153 published records. Profiles retain the underlying disclosure states. Rows are sorted by frequency; omitted profiles remain in analysis_records.csv.

## RQ2_F1 Appeals wording and decision-role cues
AUTOMATED LEXICAL CENSUS | 153 published records. Counts, not consistency judgments. Role and rationale groupings describe wording, not actual roles or consistency.

## RQ2_F2 Appeals wording across deployment stages
AUTOMATED LEXICAL CENSUS | 153 published records. Stage separates production disclosures from pilot, planned and retired systems; no maturity or causal inference.

## RQ2_T1 Appeals wording category prevalence
AUTOMATED LEXICAL CENSUS | 153 published records. Exclusive ordered wording categories; not legal consistency or validity judgments.

## RQ2_T2 Source-linked rationale audit cases
AUTOMATED LEXICAL CENSUS | 153 published records. One example per category, selected by lowest record ID. Complete extracted appeals and process fields are retained; the archived full record remains the primary source. Examples are not prevalence evidence.

## RQ3_F1 Contestation cue profiles by decision-role cues
AUTOMATED LEXICAL CENSUS | 153 published records. Percentages use all published records within each role-cue category; this grouping has not been validated as actual decision influence. Sizes appear in RQ3_T1.

## RQ3_F2 Cue-count distributions by decision-role cues
AUTOMATED LEXICAL CENSUS | 153 published records. Points are records; horizontal bars are medians. Jitter is seeded and has no substantive meaning.

## RQ3_T1 Decision-role cue group composition
AUTOMATED LEXICAL CENSUS | 153 published records. Read group comparisons alongside stage, template and document-length composition. Unclear/mixed groups are retained.

## RQ3_T2 Stage and template sensitivity comparisons
AUTOMATED LEXICAL CENSUS | 153 published records. Subsets overlap; rows are not independent experiments. No causal estimates or significance claims.

## RQ4_F1 Disclosure length and contestation cues
AUTOMATED LEXICAL CENSUS | 153 published records. A larger document offers more opportunities for lexical matches. This association does not validate usefulness, quality or causality.

## RQ4_F2 Contestation cues within disclosure-length bands
AUTOMATED LEXICAL CENSUS | 153 published records. Bands are empirical quantiles, with ties allowed to reduce the number of bands. Dots show each record; boxes summarize distributions.

## RQ4_T1 Disclosure-length association sensitivity
AUTOMATED LEXICAL CENSUS | 153 published records. No p-values are used for this finite, selectively published registry census. Ties receive average ranks.

## RQ4_T2 Similar-length contrasting record pairs
AUTOMATED LEXICAL CENSUS | 153 published records. Greedy non-overlapping pairs: largest element gap first, then closest length, then record ID. Purposive examples, not causal matching or representative effect estimates.

## RQ5_F1 Routine oversight and affected-person review cues
AUTOMATED LEXICAL CENSUS | 153 published records. Detection states denote predefined lexical patterns. A not_detected state is not proof that review is unavailable.

## RQ5_F2 Contestation cues across oversight configurations
AUTOMATED LEXICAL CENSUS | 153 published records. Configurations list routine oversight first and citizen review second. Shared source text may generate correlated cues; no causal interpretation.

## RQ5_T1 Affected-person review cues conditional on oversight cues
AUTOMATED LEXICAL CENSUS | 153 published records. Denominators include all records in each cue state. This is a wording census, not an applicability-adjusted safeguard estimate.

## RQ5_T2 Evidence for oversight configurations
AUTOMATED LEXICAL CENSUS | 153 published records. One case per observed configuration, selected by lowest record ID. Non-detection text is an analysis status, not a quotation or an absence finding.