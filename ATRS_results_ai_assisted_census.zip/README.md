# Automated lexical census
Mode: AI_ASSISTED_LEXICAL_CENSUS. Published records: 153. Census denominator: 153.
Ten figures and ten main tables answer the revised wording questions. These are exact rule counts, not confirmed safeguards or absence findings.
No human screening, independent coding or semantic accuracy score is claimed. Later linked guidance is supplementary context only.
Read captions.md, run_metadata.json and audit/negation_cue_sensitivity.csv before interpretation.
