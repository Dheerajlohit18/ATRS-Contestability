# Frozen ATRS input archive

Team Avengers, Gr10. Snapshot retrieved 26 October 2026 (Europe/Berlin).

This input archive contains 153 public UK Algorithmic Transparency Recording Standard records. It is a derived research archive of government disclosures. The records are not observations of individual decisions or appeal outcomes. Eligibility screening and substantive human coding remain planned work.

## Files supplied

- data/atrs_records.json and data/atrs_records.csv: one row per record, with metadata, extracted fields and original source URLs.
- data/atrs_sections.jsonl and data/atrs_sections.csv: 8,676 extracted sections, preserving headings, ordering, anchors and hyperlinks.
- data/data_dictionary.csv: field definitions.
- raw/api/: 153 unchanged GOV.UK Content API responses.
- raw/body_html/: corresponding original HTML body fragments from the API.
- text/: 153 extracted readable record files with source URLs.
- metadata/: collection manifest, retrieval timestamps, source-response hashes, search response, finder definition, extraction quality report, official guidance and licence page.

This is the input subset prepared for the initial notebook. The separate Excel presentation and collection script from the broader collection package are not dependencies of this archive. Use the JSON and CSV files supplied here.

## Access and intended use

Official repository: https://www.gov.uk/algorithmic-transparency-records
Lecturer's official hub: https://www.gov.uk/government/collections/algorithmic-transparency-recording-standard-hub

Extract this archive into input_data beside ATRS_Initial_Unexecuted.ipynb. The resulting path should be input_data/data/atrs_records.json. Alternatively attach the extracted folders as a Kaggle input dataset. Follow the implementation README for the complete execution and annotation workflow.

The notebook verifies the frozen JSON checksum and every response hash in metadata/download_manifest.json. It does not refresh the corpus from the live site. Retain the snapshot date because the online register may change. File hashes establish file integrity, not the substantive accuracy of government statements or human coding.

## Interpretation

The phases are 92 Production, 22 Beta/Pilot, 13 Private Beta, 11 Public Beta, 10 Pre-deployment and 5 Retired. Original template labels are retained. Records include internal tools and information services as well as systems affecting individuals. Do not treat all records as automatically eligible.

Section extraction groups Human decisions and related historical headings under human_review. A populated field does not establish adequate disclosure or an effective safeguard. Keep not disclosed, explicitly absent and not applicable distinct. Review entire records and collect relevant linked appeals guidance separately before final interpretation. That supplementary guidance is not part of this frozen core corpus.

## Attribution and reuse

Contains public sector information licensed under the Open Government Licence v3.0. Canonical URLs and retrieval timestamps are retained in the record table and manifest. Retain attribution and check licence exclusions, including personal data and third-party rights.

Licence: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
Archived licence: metadata/open_government_licence_v3.html

Suggested citation: UK public sector organisations. Algorithmic Transparency Recording Standard records. GOV.UK. Snapshot retrieved 26 October 2026. 153 records.
